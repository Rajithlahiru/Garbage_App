from django.apps import AppConfig


class ComplainApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'complain_api'
