from django.contrib import admin
from .models import Complain

# Register your models here.
admin.site.register(Complain)
