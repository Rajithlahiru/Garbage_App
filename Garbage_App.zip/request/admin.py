from django.contrib import admin

from request.models import Request


# Register your models here.
admin.site.register(Request)

